// https://webpack.js.org/configuration/
// const VueLoaderPlugin = require('vue-loader/lib/plugin');

var path = require('path')
var webpack = require('webpack')

const VueLoaderPlugin = require('vue-loader/lib/plugin')

// Add this to reference from file-loader
// Example from github/file-loader deosn't working:
// https://github.com/webpack-contrib/file-loader
var v = 'development';

module.exports = {
  mode: v, // "production" | "development" | "none"

  // disable vue warn on pro-compile
  resolve: {
	alias: {
	  'vue$': 'vue/dist/vue.esm.js'
	}
  },

  // Here the application starts executing
  // and webpack starts bundling
  output: {
    // options related to how webpack emits results
    // path: path.resolve(__dirname, "dist"), // string

    // the target directory for all output files
    // must be an absolute path (use the Node.js path module)
    filename: "bundle.js", // string

    // the filename template for entry chunks
    publicPath: "./dist/", // string
  },
  plugins: [
    // make sure to include the plugin for the magic
    new VueLoaderPlugin(),

	// https://webpack.js.org/plugins/environment-plugin/
	// new webpack.EnvironmentPlugin(['NODE_ENV'])
	new webpack.EnvironmentPlugin({
	  NODE_ENV: 'development', // use 'development' unless process.env.NODE_ENV is defined
	  DEBUG: false
	})
  ],
  module: {
	  rules: [
		  {test: /\.css$/, loader: "style-loader!css-loader" },
		  {test: /\.vue$/, loader: "vue-loader" },
		  {test: /\.(png|jpg|gif)$/, loader: "file-loader",
			options: {
				// name: '[path][name].[ext]',
				name(file) {
					// if (process.env.NODE_ENV === 'development') {
					// if (process.env.WEBPACK_MODE === 'development') {
					if (v === 'development') {
						return 'imgs/[name].[ext]';
					}
					return 'bbb [hash].[ext]';
				},
			},
		  },
		],
	  },
}

console.log(process.env.NODE_ENV);
console.log(process.env.WEBPACK_MODE);
