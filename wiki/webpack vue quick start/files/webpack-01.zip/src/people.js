let people = [
	{name: "p1"},
	{name: "p2"},
	{name: "p3"}
];

module.exports = people;
