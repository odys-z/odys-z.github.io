//'use strict';
// alert('ss');
require('./css/ex01.css');

import $ from 'jquery';

import Vue from 'vue'
import App from './App.vue'


let arr1 = require('./people.js');
console.log(arr1);

$('body').append('<h4>By jquery</h4>');

$('body').append('<ol id="ol1" type="1">');
$.each(arr1, function(k, v) {
	$('#ol1').append('<li>' + arr1[k].name + '</li>');
});

window.onload = function () {
	var v = new Vue({
		  el: '#app',
		  template: '<App/>',
		  components: { App }
		});
}
