var path = require('path')
var webpack = require('webpack')

var v = 'development';

module.exports = {
  mode: v, // "production" | "development" | "none"

  devtool: 'source-map',

  entry: './lib/TestClass.js',

  output: {
    filename: "jclient.min.js", // string

    path: path.resolve(__dirname, 'dist'),
    publicPath: "./dist/", // string

    library: 'Shapes',
    libraryTarget: 'umd'
  },
}
