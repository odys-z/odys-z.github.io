#About
This project is a test project for migrating JClient.js to webpack project using
Javascript classes.
