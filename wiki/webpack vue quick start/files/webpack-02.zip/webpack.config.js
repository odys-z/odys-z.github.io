
const path = require('path');
const webpack = require('webpack')

module.exports = {
  mode: 'development',
  devtool: 'source-map',
  entry: './src/w02.js',
  output: {
    filename: 'tutorialib.js',
    path: path.resolve(__dirname, 'dist'),
    library: 'tutorialib',
    libraryTarget: 'umd'
  },
  // externals: {
  //   lodash: {
  //      commonjs: 'lodash',
  //      commonjs2: 'lodash',
  //      amd: 'lodash',
  //      var: '_'
  //   }
  // }
};
