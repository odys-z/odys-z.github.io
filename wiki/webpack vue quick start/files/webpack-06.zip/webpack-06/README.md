Project for testing semantic table.

There are two version of webpack config.

## webpack.semantable.config.js
This config is a milestone for tutorial 2, the [semantable(../../../../wiki/webpack vue quick start/tutorial-02.html)] section.

- demo page
test/simple.html and test/semantable.html.

## webpack.jvue.config.js
webpack.jvue.config.js is used to compile jview-menu.vue into jviews.js,

where the jview-menu.vue is the equivalent of App.vue, the main entry of a SPA.

### static menu
- demo page
test/index-static.html

- app entry (jclient/jview.vue)
lib/views/jview-menu.vue

### dynamic menu
- demo page
test/index.html

- app entry (jclient/jview.vue)
lib/views/jview-menu-dyna.vue
