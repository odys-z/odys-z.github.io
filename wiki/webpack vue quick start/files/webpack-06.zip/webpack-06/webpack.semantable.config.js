/**This configuration is used for semantable example in tutorial 2.
 * Webpack will compile vue.view.js into jviews.js.
 * The vue.view.js is the jclient's vue lib.
 * There is another config.js file for compile all jclient into library, the webpack.jvue.config.js.*/
var path = require('path')
var webpack = require('webpack')

const VueLoaderPlugin = require('vue-loader/lib/plugin')

var v = 'development';

module.exports = {
  mode: v, // "production" | "development" | "none"
  devtool: 'source-map',
  // entry: './lib/jclient.js',
  entry: {views: './lib/views/vue.view.js', client: './lib/jclient.js'},

  output: {
    // filename: "jclient.min.js", // string
    // filename: "semantic-views.min.js", // string
    filename: "j[name].min.js", // string

    path: path.resolve(__dirname, 'dist'),
    publicPath: "./dist/", // string

    library: 'j[name]',
    libraryTarget: 'umd'
  },

  plugins: [
    new VueLoaderPlugin(),
  ],

  module: {
	rules: [
		{test: /\.js$/, exclude: /node_modules/, loader: "babel-loader" },
		{test: /\.css$/, loader: "style-loader!css-loader" },
		{test: /\.vue$/, loader: "vue-loader" },
		  // {test: /\.(png|jpg|gif)$/, loader: "file-loader",
			// options: {
			// 	name(file) {
			// 		if (v === 'development') {
			// 			return 'imgs/[name].[ext]';
			// 		}
			// 		return 'bbb [hash].[ext]';
			// 	},
			// },
		  // },
		],
	},
}
