/**This configuration is used for menu example in tutorial 2.
 * Webpack will compile vue.view-menu.js into jviews.js.
 * The vue.view-menu.js is the main entry of jclient's vue lib.
 * There is another config.js file for compile semantable into library, the webpack.semantable.config.js.*/
var path = require('path')
var webpack = require('webpack')

const VueLoaderPlugin = require('vue-loader/lib/plugin')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')

var v = 'development';

module.exports = {
  mode: v, // "production" | "development" | "none"
  devtool: 'source-map',
  // entry: {vue: './lib/views/jview-menu.vue', client: './lib/jclient.js'},
  entry: {vue: './test/home.js'},

  output: {
    // filename: "jclient.min.js", // string
    // filename: "semantic-views.min.js", // string
    filename: "j[name].min.js", // string

    path: path.resolve(__dirname, 'dist'),
    publicPath: "./dist/", // string

    library: 'j[name]',
    libraryTarget: 'umd'
  },

  plugins: [
    new VueLoaderPlugin(),
    new MiniCssExtractPlugin({ filename: "vue-sidebar-menu.css" })
  ],

  module: {
	rules: [
		{test: /\.js$/, exclude: /node_modules/, loader: "babel-loader" },
		{test: /\.css$/,
          use: [
            'style-loader',
            'css-loader',
            'postcss-loader',
          ] },
		// npm install --save-dev mini-css-extract-plugin
		// npm install postcss-loader --save-dev
		// npm install sass-loader --save-dev
		// npm install npm-sass
		{test: /\.scss$/,
			use: [
				'vue-style-loader',
				'css-loader',
				'postcss-loader',
				'sass-loader'
			]},
			// use: [ MiniCssExtractPlugin.loader,
			// 					'css-loader', 'postcss-loader', 'sass-loader' ] },
		{test: /\.vue$/, loader: ["vue-loader"] },
		  // {test: /\.(png|jpg|gif)$/, loader: "file-loader",
			// options: {
			// 	name(file) {
			// 		if (v === 'development') {
			// 			return 'imgs/[name].[ext]';
			// 		}
			// 		return 'bbb [hash].[ext]';
			// 	},
			// },
		  // },
		],
	},
}
