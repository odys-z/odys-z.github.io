import Vue from 'vue/dist/vue.js'
import VueRouter from 'vue-router';

import SidebarMenu from '../lib/components/vue/menu/SidebarMenu.vue'

// from application, referencing lib main entry, the view
// import App from './App.vue'
import jvue from '../lib/views/jview-menu.vue'

Vue.use(SidebarMenu)

Vue.use(jvue)

Vue.use(VueRouter)

const Dashboard = { template: '<div>Dashboard Page</div>' }
const Charts = { template: '<div>Charts Page</div>' }
const Tables = { template: '<div>Tables Page</div>' }
const Auth = { template: '<div>Auth <router-view/></div>' }
const Login = { template: '<div>Login Page</div>' }
const Registration = { template: '<div>Registration Page</div>' }

const router = new VueRouter({
  routes: [
    {
      path: '/',
      name: 'Dashboard',
      component: Dashboard,
    },
    {
      path: '/charts',
      name: 'Charts',
      component: Charts,
    },
    {
      path: '/tables',
      name: 'Tables',
      component: Tables,
    },
    {
      path: '/auth',
      name: 'Auth',
      component: Auth,
      children: [
        {
          path: 'login',
          name: 'Login',
          component: Login,
        },
        {
          path: 'registration',
          name: 'Registration',
          component: Registration,
        }
      ]
    },
  ]
})

Vue.component('sidebar-menu', SidebarMenu);

export function menu(id) {
	if (id === undefined)
		id = '#app';
	return new Vue(Object.assign({}, jvue, { el: id }, {router: router}));
}
