// https://webpack.js.org/configuration/
// const VueLoaderPlugin = require('vue-loader/lib/plugin');

var path = require('path')
var webpack = require('webpack')

const VueLoaderPlugin = require('vue-loader/lib/plugin')

// Add this to reference from file-loader
// Example from github/file-loader deosn't working:
// https://github.com/webpack-contrib/file-loader
// Use this for reference
var v = 'production';

module.exports = {
  mode: v, // "production" | "development" | "none"

  devtool: 'source-map',

  // disable vue warn on pro-compile
  // resolve: {
	// alias: {
	//   'vue$': 'vue/dist/vue.esm.js'
	// }
  // },

  entry: './src/test.js',
  output: {
    // the target directory for all output files
    // must be an absolute path (use the Node.js path module)
    filename: "datable.component.js", // string

    path: path.resolve(__dirname, 'dist'),
    // the filename template for entry chunks
    publicPath: "./dist/", // string
  },

  plugins: [
    // make sure to include the plugin for the magic
    new VueLoaderPlugin(),

	// https://webpack.js.org/plugins/environment-plugin/
	// new webpack.EnvironmentPlugin(['NODE_ENV'])
	// new webpack.EnvironmentPlugin({
	//   NODE_ENV: v, // use 'development' unless process.env.NODE_ENV is defined
	//   DEBUG: false
	// })
  ],

  module: {
	  rules: [
		  {test: /\.css$/, loader: "style-loader!css-loader" },
		  {test: /\.vue$/, loader: "vue-loader" },
		  {test: /\.(png|jpg|gif)$/, loader: "file-loader",
			options: {
				name(file) {
					if (v === 'development') {
						return 'imgs/[name].[ext]';
					}
					return 'bbb [hash].[ext]';
				},
			},
		  },
		],
	  },
}
