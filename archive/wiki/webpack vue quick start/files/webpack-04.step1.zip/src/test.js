import Vue from 'vue';
import DataTable from './components/DataTable.vue';

function test () {
	// Vue.component('comp-item', {
	// 	props: ['item'],
	//     template: '<user-pop :user="item.user" :main="item.user.name"></user-pop>'
	// });
	//
	// var app1 = new Vue({
	// 	el: '#app',
	// 	props: ['item'],
	// 	data: {
	//       messages:[
	//         {
	//           user: {name: 'Neo Ighodaro',username: 'neoighodaro',email: 'neo@gmail.com',
	// 		  	profile: {profile_image:'https://avatars3.githubusercontent.com/u/807318?s=400&v=4'},
	//           },
	//           message: 'How have you been'
	//         },
	//         {
	//           user: {name: 'Osita Chibuike',username: 'mozartted',email: 'mozart@gmail.com',
	// 		  	profile: {profile_image:'https://avatars2.githubusercontent.com/u/11639772?s=460&v=4'},
	//           },
	//           message: "I'm alright, This is an article right??"
	//         },
	//         {
	//           user: {name: 'Neo Ighodaro',username: 'neoighodaro',email: 'neo@gmail.com',
	// 		  	profile: {profile_image:'https://avatars3.githubusercontent.com/u/807318?s=400&v=4'},
	//           },
	//           message: 'Yea, I think so'
	//         },
	//       ]
	//     },
	// });
}

Vue.component({DataTable});

window.onload = function initttt() {
	console.log(this);
	new Vue({
		render: h => h(DataTable)
	}).$mount('#app')
	// https://vuejs.org/v2/api/#vm-mount
	// });
}
