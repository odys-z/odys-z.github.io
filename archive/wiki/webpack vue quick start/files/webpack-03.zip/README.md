#About

Source project for wiki/tutorial2 Thinking in Vue Component.

The project export a basic Vue component, popping preview window, which is wraped into a Vue component.

#Quick Start
Check test.html which is using old fashion <script> tags to use the component.
